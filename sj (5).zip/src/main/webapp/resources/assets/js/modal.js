$(function(){
    $("#popbutton").click(function(){
        $('div.modal').modal();
    })
})