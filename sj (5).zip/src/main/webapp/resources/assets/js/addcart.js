// 서버로 전송할 데이터

const form = {
		pno : '${product.pno}',
		pname : '${product.pname}',
		price : '${product.price}',
		stock : '${product.stock}',
}

$(".btn btn-lg btn-primary").on("click", function(e){

	});