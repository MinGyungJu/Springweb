package com.javassem.domain;

import lombok.Data;

@Data
public class ListOrderVO {

	private int cno;
	private int pno;
	private int ocnt;
	
}
