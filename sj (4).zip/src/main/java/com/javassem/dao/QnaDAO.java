package com.javassem.dao;

import com.javassem.domain.QuestionVO;

public interface QnaDAO {
	public void insertContact(QuestionVO vo);
	public void updateContact(QuestionVO vo);
	public void deleteContact(QuestionVO vo);
	
}
