$(function(){ 
	window.onload = function(){	
		if (location.href.indexOf('reloaded')==-1) location.replace(location.href+'?reloaded');
	};
	
	
});

