package com.javassem.domain;

import lombok.Data;

@Data
public class OrderVO {

	private int lono;
	private int cno;
	private String odrdate;
	private String addr;
	
}
