package com.javassem.domain;

import lombok.Data;

@Data
public class AnswerVO {

	private int qno;
	private int mno;
	private String cno;
	private String amessage;

}
