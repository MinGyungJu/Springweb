package com.javassem.service;

public interface PasswordEncoder {

	String encode(String pw);


}
