package com.javassem.domain;

import lombok.Data;

@Data
public class CustomerVO {

	private int cno;
	private String name;
	private String gender;
	private String id;
	private String pw;
	private String tel;
	private String email;
	private String addr;
	
}
